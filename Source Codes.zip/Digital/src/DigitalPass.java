import java.util.Scanner;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;   


public class DigitalPass {
	
	DigitalPass() {
		
	}
	
	private String firstName;
	private String middleName;
	private String lastName;
	private int age;
	
	private String identificationNumber;

	private boolean isUserFound;
	private boolean isUserTested;
	private boolean isUserVaxxed;
	private boolean isRegistered;
	private boolean isVerified;
	
	private Connection connect;
	
	private int doseAmount;
	private String vaccinationStatus;
	
	private boolean freePass;
	
	
	// user registers for new account, provide identification number [666666]
	public void userRegister() throws SQLException {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter First Name");
		this.firstName = input.nextLine();
		
		System.out.println("Enter Middle Name");
		this.middleName = input.nextLine();
		
		System.out.println("Enter Last Name");
		this.lastName = input.nextLine();
		
		System.out.println("Enter Age:");
		this.age = input.nextInt();
		
		if(this.age < 10) {
			this.freePass = true;
			freePassPrivilege();
		}
		
		// generate ID number
		Random generateID = new Random();
		
		int generated = generateID.nextInt(999999);
		
		this.identificationNumber = Integer.toString(generated);
		System.out.println(this.identificationNumber);
		
		this.isRegistered = true; // user is registered
		
		
		createProfileDatabase();		
	}
	
	// add data to database
	private void createProfileDatabase() throws SQLException {
			
		
		String path = "jdbc:sqlite:profileDB.db";
		
		String createTablesql = "CREATE TABLE NOT EXISTS Profiling " + "firstName varchar(255), " + "middleName varchar(255), "
				+ "lastName varchar(255), " + "age integer, " + "identificationNumber varchar(255)";

		
		try(Connection connect = DriverManager.getConnection(path); java.sql.Statement stmt = this.connect.createStatement()) {
			stmt.execute(createTablesql);
		} 
		
		catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		
		/*try {
			String path = "jdbc:sqlite:profileDB.db";
			

			this.connect = DriverManager.getConnection(path);
			
			System.out.println("Opened Database Successfully!");
		
			try {
				deleteTable(); // table must exist
			}
			
			catch (Exception ignored) {
				// Do Nothing - table doesn't exist
			}
			
			
			userRegister();
			
			
			System.out.println("Inserting data: ");
			insertProfile();
			
			System.out.println();
			System.out.println("Displaying Database: ");
			
			displayProfilingDatabase();
		} 
		catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
		}
		
		finally {
			
			if(this.connect != null) {
				
				try {
					this.connect.close();
				} 
				
				catch (SQLException e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
			}
		} */  
	}
		
	
	private void displayProfilingDatabase() throws SQLException {
		String tableName = "Profiling";
		String selectSQL = "SELECT * from" + tableName;
		
		java.sql.Statement stmt = this.connect.createStatement();
		ResultSet rs = stmt.executeQuery(selectSQL);
		
		System.out.println("-------------" + tableName + "--------------");
		
		
		while(rs.next()) {
			System.out.println("First name" + rs.getString("firstName"));
			System.out.println("Middle name" + rs.getString("middleName"));
			System.out.println("Last name" + rs.getString("lastname"));
			System.out.println("Age: " + rs.getInt("age"));
		}
		
		System.out.println("--------------------------------------------");
		
	}

	private void insertProfile() throws SQLException {
		
		String firstName = this.firstName;
		String middleName = this.middleName;
		String lastName = this.lastName;
		int age = this.age;
		String ID = this.identificationNumber;
		
		
		String insertSQL = "INSERT INTO Profiling(firstName, middleName, lastName, age, ID) VALUES(?, ?, ?, ?)";
		
		PreparedStatement pstmt = this.connect.prepareStatement(insertSQL);
		pstmt.setString(1, firstName);
		pstmt.setString(2, middleName);
		pstmt.setString(3, lastName);
		pstmt.setInt(4, age);
		pstmt.setString(5, ID);
		pstmt.executeUpdate();
	}
	

	private void deleteTable() throws SQLException {
		String deleteTableSQL = "DROP TABLE Profiling";
		java.sql.Statement stmt = this.connect.createStatement();
		stmt.execute(deleteTableSQL);
	}

	
	
	/* private void updateTable(Connection connect) {
		String updateTableSQL = "UPDATE warehouses SET fullName = ? , "
                + "middleName = ? "
                + "lastName = ? "
                + "age = ? "
                + "ID = ?";
		
		try (PreparedStatement pstmt = connect.prepareStatement(updateTableSQL)) {

            // set the corresponding parameters
            pstmt.setString(1, this.firstName);
            pstmt.setString(2, this.middleName);
            pstmt.setString(3, this.lastName);
            pstmt.setInt(4, this.age);
            pstmt.setString(5, this.identificationNumber);
            // update 
            pstmt.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		
	} */
	
	//
	public void freePassPrivilege() {
		// trigger the following in an unlimited group
	}
	
	// user logs into account, program checks to see if user already registered by searching database
	public void userLogin() {
		
	}
	
	// Add '111' at the end of the identification number created in userRegister() to show that user successfully verified
	public void verifyUser() {
		// user also verified if he has all the required vaccines
		// if user fails verification, then they will either: recovered for covid / covid tests conditions
	}
	
	
	// check if user is: vaccinated / tested -ve for covid / recovered from covid
	public void checkStatus() {
		
	}
	
	// Check to see if venue needs a negative test + vaccination OR just vaccination required.
	// If user unvaccinated, then check to see if venue requires Lateral or PCR test
	// Also check if the venue accepts users recovered from COVID only.
	public String venueRestrictions() {
		return "";
	}
	
	
	// Getters and Setters Section

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	
	public static void main(String[] args) throws SQLException {
		
		DigitalPass pass = new DigitalPass();
		
		
		pass.userRegister();
		
		
	}
	
	
	
	
	
}
