module digitalpassport {
    requires javafx.graphics;
    requires javafx.fml;
    requires javafx.controls;
    requires java.sql;
    requires mysql.connector.java;

    opens digitalpassport;
}